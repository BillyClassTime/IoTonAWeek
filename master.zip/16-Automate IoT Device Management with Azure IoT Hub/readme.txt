Setup - script used to configure the Azure environment for this lab
Starter - code project files used by students to complete this lab
Final- completed code project files used by students to complete this lab
