Setup - script used to configure the Azure environment for this lab

Note: In addition to the lab17-setup.azdi script that is used to configure the Azure environment, this lab includes 2 additional script files that are used during the lab:

* gen-dev-certs.sh
* install-tools.sh 

Starter - code project files used by students to complete this lab
