There is no setup script or code projects required for this lab
