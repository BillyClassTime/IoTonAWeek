no setup script for this lab
