// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

// This application uses the Azure IoT Hub device SDK for .NET
// For samples see: https://github.com/Azure/azure-iot-sdk-csharp/tree/master/iothub/device/samples

// INSERT using statements below here

namespace CaveDevice
{
    class Program
    {
        // INSERT variables below here

        // INSERT Main method below here

        // INSERT SendDeviceToCloudMessagesAsync method below here

        // INSERT CreateMessageString method below here
    }

    // INSERT EnvironmentSensor class below here
}